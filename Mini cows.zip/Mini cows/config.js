// Supabase connection for Mini Highland Co. (publishable values are safe in a public website).
window.SUPABASE_URL    = "https://argtxblhhsfcakezsztr.supabase.co";
window.SUPABASE_KEY    = "sb_publishable_7JM_pdGsmZD6IPSiuGrfHw_H8L2KZ31";
window.SUPABASE_BUCKET = "cow-images";
// NEVER put the secret key or the service_role key in this file.
